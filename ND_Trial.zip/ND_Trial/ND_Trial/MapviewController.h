//
//  MapviewController.h
//  ND_Trial
//
//  Created by Prince on 1/17/17.
//  Copyright © 2017 ChengShui. All rights reserved.
//

#import <UIKit/UIKit.h>

#import <MapKit/MapKit.h>

@interface MapviewController : UIViewController <MKMapViewDelegate>
@property (strong, nonatomic) IBOutlet MKMapView *m_Mapview;
- (IBAction)move_Clicked:(id)sender;
@property (weak, nonatomic) IBOutlet UILabel *cal_distence;
@end
