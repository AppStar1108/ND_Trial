//
//  MapviewController.m
//  ND_Trial
//
//  Created by Prince on 1/17/17.
//  Copyright © 2017 ChengShui. All rights reserved.
//

#import "MapviewController.h"

//Frameworks import
#import <Foundation/Foundation.h>
#import <CoreLocation/CoreLocation.h>
#import "PrefixHeader.pch"




@interface MapviewController () <CLLocationManagerDelegate>
@property (weak, nonatomic) IBOutlet UILabel *cur_title;
@property (weak,nonatomic) IBOutlet UILabel *cur_subtitle;
@property (weak,nonatomic) IBOutlet UILabel *cur_position;
@property (strong,nonatomic) NSArray *region;
@property (strong,nonatomic) NSMutableArray *arr_title;
@property (strong,nonatomic) NSMutableArray *arr_subtitle;
@property (strong,nonatomic) NSMutableArray *arr_coordination;
@property (strong,nonatomic) NSMutableArray *arr_hour;
@property (strong,nonatomic) MKUserLocation *my_user_location;


@property (strong, nonatomic) CLLocationManager* locationManager;

@end

@implementation MapviewController

- (void)viewDidLoad {
    [super viewDidLoad];
// AFNetworking Faramework Service
        NSString *str_url=@"http://192.168.0.16/1/AEDs.json";
        AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
        [manager GET:str_url parameters:nil progress:nil success:^(NSURLSessionTask *task, id responseObject) {
        
        self.region=[responseObject objectForKey:@"aeds"];
        self.arr_title=[NSMutableArray arrayWithCapacity:self.region.count];
        self.arr_subtitle=[NSMutableArray arrayWithCapacity:self.region.count];
        self.arr_coordination=[NSMutableArray arrayWithCapacity:self.region.count];
        self.arr_hour=[NSMutableArray arrayWithCapacity:self.region.count];
            
        NSLog(@"JSON: %@", self.region);

        self.arr_coordination=[self.region valueForKey:@"geo"];
        self.arr_title=[self.region valueForKey:@"Installation"];
        self.arr_subtitle=[self.region valueForKey:@"ambulance"];
        self.arr_hour=[self.region valueForKey:@"hours_open"];
        
//      NSLog(@"JSON: %@", self.region);
        NSLog(@"Hours at Open: %@",self.arr_hour);

        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        NSLog(@"Error: %@", error);
    }];
//////////////////////////////////////////////////////////////////////////////////
    // JSON Data Pasing end
    
    self.m_Mapview.delegate = self;
    self.m_Mapview.mapType = MKMapTypeStandard;
    self.m_Mapview.showsUserLocation = YES;
    
    
    if ([CLLocationManager locationServicesEnabled]) {
        if (!self.locationManager) {
            self.locationManager = [[CLLocationManager alloc] init];
        }
        self.locationManager.delegate = self;
        self.locationManager.distanceFilter = kCLDistanceFilterNone;
        self.locationManager.desiredAccuracy = kCLLocationAccuracyBest;
        
        if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 8.0)
            [self.locationManager requestWhenInUseAuthorization];
        
        [self.locationManager startUpdatingLocation];
    }
   
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/


#pragma mark - MKMapView delegate

- (nullable MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(id <MKAnnotation>)annotation{
    // If it's the user location, just return nil.
    if ([annotation isKindOfClass:[MKUserLocation class]])
        return nil;
    
    // Handle any custom annotations.
    if ([annotation isKindOfClass:[MKPointAnnotation class]])
    {
        // Try to dequeue an existing pin view first.
        MKAnnotationView *pinView = (MKAnnotationView*)[mapView dequeueReusableAnnotationViewWithIdentifier:@"CustomPinAnnotationView"];
        if (!pinView)
        {
            // If an existing pin view was not available, create one.
            pinView = [[MKAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:@"CustomPinAnnotationView"];
            //pinView.animatesDrop = YES;
            pinView.canShowCallout = YES;
            
            pinView.image = [UIImage imageNamed:@"GrnPin"];
            pinView.calloutOffset = CGPointMake(0, 16);
            
        } else {
            pinView.annotation = annotation;
        }
        return pinView;
    }
    return nil;

}

- (void)mapView:(MKMapView *)mapView didAddAnnotationViews:(NSArray<MKAnnotationView *> *)views{
    
}

- (void)mapView:(MKMapView *)mapView didDeselectAnnotationView:(MKAnnotationView *)view
{
    view.image=[UIImage imageNamed:@"GrnPin"];
}
- (void)mapView:(MKMapView *)mapView didSelectAnnotationView:(MKAnnotationView *)view
{
    MKPointAnnotation *annotation= (MKPointAnnotation *)view.annotation;
    self.cur_title.text=annotation.title;
    self.cur_subtitle.text=annotation.subtitle;
//    self.cur_position.text=[NSString stringWithFormat:@"%f      %f",annotation.coordinate.latitude,annotation.coordinate.longitude];
    self.cur_position.text=[NSString stringWithFormat:@"%f      %f",annotation.coordinate.latitude,annotation.coordinate.longitude];
//    annotation.
    [self.cur_position setTextColor:[UIColor whiteColor]];
    
    CLLocation *initial_location=[[CLLocation alloc] initWithLatitude:self.my_user_location.coordinate.latitude longitude:self.my_user_location.coordinate.longitude];
    CLLocation *sel_location=[[CLLocation alloc] initWithLatitude:annotation.coordinate.latitude longitude:annotation.coordinate.longitude];
    CLLocationDistance distence=[initial_location distanceFromLocation:sel_location];
//    NSLog(@"%f",distence);
    [self.cal_distence setText:[NSString stringWithFormat:@"%.3f miles",distence/1609.344]];
    view.image=[UIImage imageNamed:@"GrnPinSel"];
    
}


#pragma mark - CLLocationManager delegate

- (void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation {
    NSLog(@"Latitude :  %f", newLocation.coordinate.latitude);
    NSLog(@"Longitude :  %f", newLocation.coordinate.longitude);
    
    [manager stopUpdatingLocation];
    }



- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error {
    NSLog(@"didFailWithError: %@", error);
}




- (void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray<CLLocation *> *)locations{
    
    
}

- (void)mapView:(MKMapView *)mapView didUpdateUserLocation:(MKUserLocation *)userLocation
{
    self.my_user_location=userLocation;
    // Add an annotation
//    MKPointAnnotation *point = [[MKPointAnnotation alloc] init];
//    point.coordinate = userLocation.coordinate;
//    point.title = @"My Location";
//    point.subtitle = @"This is my GPS position";
//    [self.m_Mapview addAnnotation:point];
//    [self.cur_title setText:userLocation.title];
//    [self.cur_subtitle setText:userLocation.subtitle];
//    [self.cur_position setText:[NSString stringWithFormat:@"%f          %f",userLocation.coordinate.latitude,userLocation.coordinate.longitude]];
    
    
    // All AEDs pinning
    for(int i = 0; i<self.region.count;i++)
    {
        NSArray *arr_coordnate = [self.arr_coordination[i] componentsSeparatedByString:@","];
        CLLocationCoordinate2D newCoord = {[[arr_coordnate objectAtIndex:0] floatValue],[[arr_coordnate objectAtIndex:1] floatValue] };
        MKPointAnnotation *annotation=[[MKPointAnnotation alloc] init];
        annotation.coordinate=newCoord;
        annotation.title=self.arr_title[i];
        annotation.subtitle=self.arr_subtitle[i];
        [self.m_Mapview addAnnotation:annotation];
        //            NSLog(@"x=   %f  y=   %f",[[arr_coordnate objectAtIndex:0] floatValue],[[arr_coordnate objectAtIndex:1] floatValue]);
        //[mp release];
    }

    MKCoordinateRegion region = MKCoordinateRegionMakeWithDistance(userLocation.coordinate, 20000, 20000);
    [self.m_Mapview setRegion:[self.m_Mapview regionThatFits:region] animated:YES];
    [self.m_Mapview setCenterCoordinate:userLocation.coordinate animated:YES];
    
//    NSDateFormatter *dateFormatter=[[NSDateFormatter alloc] init];
//    [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
//    // or @"yyyy-MM-dd hh:mm:ss a" if you prefer the time with AM/PM
//    NSLog(@"%@",[dateFormatter stringFromDate:[NSDate date]]);

}


- (IBAction)move_Clicked:(id)sender {
    [self.m_Mapview setCenterCoordinate:self.my_user_location.coordinate animated:YES];
    
    
}
@end
