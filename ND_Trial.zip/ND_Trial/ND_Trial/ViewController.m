//
//  ViewController.m
//  ND_Trial
//
//  Created by Prince on 1/16/17.
//  Copyright © 2017 ChengShui. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()



@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    shouldHideStatusBar = NO;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (BOOL)prefersStatusBarHidden {
    return shouldHideStatusBar;
}


- (IBAction)Accept_click:(id)sender {
//    [self performSegueWithIdentifier: @"MapView_Segue" sender:Nil];
    
}
- (IBAction)Cancel_click:(id)sender {
    
    
}

@end
