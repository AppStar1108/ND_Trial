//
//  main.m
//  ND_Trial
//
//  Created by Prince on 1/16/17.
//  Copyright © 2017 ChengShui. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
